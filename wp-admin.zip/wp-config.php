<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wpvuebytfm_main' );

/** Database username */
define( 'DB_USER', 'wpvuebytfm_main' );

/** Database password */
define( 'DB_PASSWORD', 'g_d)+KTCy5~q' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ';`H{:^mb]R.!&}r&2xSjYtX4{%cek.hth;xqUMt:,CM[*8i{}O%WgiV1+3-~#^e1' );
define( 'SECURE_AUTH_KEY',  '0_1q/A=QA5>5>%zP|nPvnyaDyeWh-|4VpVJ?t3&c<[Bjr|Oa0vN+;Um60B%O{=V8' );
define( 'LOGGED_IN_KEY',    '[-9yKhG<A@FN)J,4ugnG`==JS|O&wbLMlcXpp!8pPXgg<tlb JVq5,UYb7S#Kbzu' );
define( 'NONCE_KEY',        '9s6<Rl)T|MX4A_cZp?E `r##&{(5(R~IA1rB.-t0Xd?p)un<<d7#=$i6Wfv(n{sK' );
define( 'AUTH_SALT',        'i9Q 2v(PlKpyT301AX.iK}w-gf-e_#DV-E`i.-p{LP<[k^MWhtJ>`jxjw6o$kcjf' );
define( 'SECURE_AUTH_SALT', 'Q_`,b2vnYZ=w7kE[ZG;-b;+a$,/*G1x?6)Eo*YyEdQ|{~v)5kPG]gquF&Iz.!oa}' );
define( 'LOGGED_IN_SALT',   'm+<pRE?*,< z3Y)g_qav]Y15D>SKr]=Z!9/*EGn3<{+0?2O?H!~An(@_$~@1Vtw4' );
define( 'NONCE_SALT',       '+!p@*iYF_uc]nJ@S2q1pq@yn{rA+n8g[HQ55Y.V*)+:LR@^N Vca=kh~~kZw.m -' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
